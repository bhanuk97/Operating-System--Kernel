#include <unistd.h>

int
main(int argc, char **argv)
{
        halt();
        return 0;
}

